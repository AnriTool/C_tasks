#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	FILE *in, *out;
	char name[100],surname[100],secondname[100];
	int date,mydate;


	in = fopen("names.txt","r");
	out = fopen("newnames.txt","w");

	printf("enter date: ");
	scanf("%d",&mydate);

	fprintf(out,"����: %d\n",mydate);

	while (fscanf(in,"%s%s%s%d\n",&name,&surname,&secondname,&date) != EOF) {
		if (date > mydate)
			fprintf(out,"%s %s %s %d\n",name,surname,secondname,date);
	}
	fclose(in);
	fclose(out);
	return 0;
}
